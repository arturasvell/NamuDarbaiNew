var searchData=
[
  ['operator_28_29_78',['operator()',['../class_student.html#ae193c3a3ab0201c00692f5b67a0fbac6',1,'Student']]],
  ['operator_2b_79',['operator+',['../class_student.html#ae9db8767724aaf271361d7d1fa294e41',1,'Student']]],
  ['operator_2d_80',['operator-',['../class_student.html#a8991501e7f21f16ace90e22ec9d247fd',1,'Student']]],
  ['operator_2f_81',['operator/',['../class_student.html#acdd7a9c87222eb7b16bdde660f8c122f',1,'Student']]],
  ['operator_3d_82',['operator=',['../class_student.html#a7e2a3a4461352248b7311089c14b51b3',1,'Student']]]
];
