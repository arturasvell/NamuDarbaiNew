var searchData=
[
  ['displaynamesurname_72',['DisplayNameSurname',['../class_person.html#ae109e9aba120020f39f25f4eaf9cc86a',1,'Person::DisplayNameSurname()'],['../class_student.html#a58fd82ba22184b5f143431e706870e43',1,'Student::DisplayNameSurname()']]]
];
