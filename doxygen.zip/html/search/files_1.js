var searchData=
[
  ['logic_2ecpp_58',['logic.cpp',['../logic_8cpp.html',1,'']]],
  ['logic_2eh_59',['logic.h',['../logic_8h.html',1,'']]]
];
