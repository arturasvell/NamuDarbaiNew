var searchData=
[
  ['deque_10',['DEQUE',['../logic_8h.html#a2a3c0067e44c5ef3210a256d06c16b0fa71c7d3df272cfdc114b998404e18628c',1,'logic.h']]],
  ['displaynamesurname_11',['DisplayNameSurname',['../class_person.html#ae109e9aba120020f39f25f4eaf9cc86a',1,'Person::DisplayNameSurname()'],['../class_student.html#a58fd82ba22184b5f143431e706870e43',1,'Student::DisplayNameSurname()']]],
  ['doxygen_5flog_2etxt_12',['doxygen_log.txt',['../doxygen__log_8txt.html',1,'']]]
];
