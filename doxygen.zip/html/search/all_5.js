var searchData=
[
  ['generatetxtfiles_14',['GenerateTxtFiles',['../logic_8cpp.html#a0fbb39e3e0c84e8aa1f81ca80c9a025c',1,'GenerateTxtFiles(int amountOfFiles):&#160;logic.cpp'],['../logic_8h.html#a0fbb39e3e0c84e8aa1f81ca80c9a025c',1,'GenerateTxtFiles(int amountOfFiles):&#160;logic.cpp']]],
  ['generationalgorithm_15',['GenerationAlgorithm',['../logic_8cpp.html#a2859bc2cc9c91df450622c51b8dc0073',1,'GenerationAlgorithm(int amountToGenerate, int counter):&#160;logic.cpp'],['../logic_8h.html#a2859bc2cc9c91df450622c51b8dc0073',1,'GenerationAlgorithm(int amountToGenerate, int counter):&#160;logic.cpp']]]
];
