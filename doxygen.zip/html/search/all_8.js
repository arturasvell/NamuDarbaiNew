var searchData=
[
  ['namų_20darbų_20sistema_22',['Namų darbų sistema',['../md__r_e_a_d_m_e.html',1,'']]],
  ['name_23',['name',['../class_person.html#a669b64897b4d823a27bb5866368d4dfa',1,'Person::name()'],['../class_student.html#a671f6b115a158653a0f0bece34ea0667',1,'Student::name()'],['../class_student.html#ae8ffed3b5235e256636f1f747d171f5d',1,'Student::Name()']]],
  ['namudarbai_2ecpp_24',['NamuDarbai.cpp',['../_namu_darbai_8cpp.html',1,'']]]
];
