var searchData=
[
  ['method_109',['Method',['../logic_8h.html#a2a3c0067e44c5ef3210a256d06c16b0f',1,'logic.h']]]
];
